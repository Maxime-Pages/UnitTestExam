import org.junit.Test;

public class TaskManagerTest {

    @Test
    public void ManagerBeginsEmpty()
    {
        
    }
    
}
